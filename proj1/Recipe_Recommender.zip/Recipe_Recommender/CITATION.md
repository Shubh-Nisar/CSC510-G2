cff-version: 1.2.0
message: "If you use this software, please cite it as below."
authors:

- family-names: "Patel"
  given-names: "Parth Vijaykumar"
  orcid: "https://orcid.org/0000-0000-0000-0000"
- family-names: "Shah"
  given-names: "Neel Kamlesh"
  orcid: "https://orcid.org/0000-0000-0000-0000"
- family-names: "Shah"
  given-names: "Jay Rajiv"
  orcid: "https://orcid.org/0000-0000-0000-0000"
- family-names: "Tathavadkar"
  given-names: "Ameya"
  orcid: "https://orcid.org/0000-0000-0000-0000"
- family-names: "Shah"
  given-names: "Harshil"
  orcid: "https://orcid.org/0000-0000-0000-0000"
  title: "Reciepe Recommender"
  version: 1.0.0
  doi: 10.5281/zenodo.5534986
  date-released: 2021-09-29
  url: "https://doi.org/10.5281/zenodo.5534986"
