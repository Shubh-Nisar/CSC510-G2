const pwd = {
  password: "Macromedic@123",
};

module.exports = pwd;
